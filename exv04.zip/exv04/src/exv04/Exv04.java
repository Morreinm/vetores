package exv04;

import java.util.Scanner;

public class Exv04 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String a[] = new String[5];
        String f[] = new String[5];
        String v[] = new String[10];
        int x = 0, y = 0;

        System.out.println("digite 5 animais");

        for (int i = 0; i < 5; i++) {
            System.out.print("animal " + (i + 1) + ": ");
            a[i] = teclado.nextLine();
        }

        System.out.println("digite 5 frutas");

        for (int i = 0; i < 5; i++) {
            System.out.print("fruta " + (i + 1) + ": ");
            f[i] = teclado.nextLine();
        }

        for (int i = 0; i < 10; i++) {
            if (i % 2 == 0) {
                v[i] = f[x];
                x++;
            } else {
                v[i] = a[y];
                y++;
            }
        }

        for (int i = 0; i < 10; i++) {
            if (i % 2 == 0) {
                System.out.print(v[i] + " : ");
            } else {
                System.out.println(v[i]);
            }
        }

    }
}
