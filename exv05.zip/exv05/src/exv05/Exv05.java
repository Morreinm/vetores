package exv05;

import java.util.Scanner;

public class Exv05 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int v[] = new int[100];
        int n[] = new int[5];
        int qtd;

        for (int i = 0; i < 100; i++) {
            v[i] = (int) (Math.random() * 10);
        }

        System.out.println("digite 5 numeris:");

        for (int i = 0; i < 5; i++) {
            System.out.print("num" + (i + 1) + ": ");
            n[i] = teclado.nextInt();
            qtd = 0;

            for (int j = 0; j < 100; j++) {
                if (v[j] == n[i]) {
                    System.out.println("numero encontrado na posicao:" + (j + 1));
                    qtd++;
                }
            }

            if (qtd == 0) {
                System.out.println("numero nao encontrado");
            }

            System.out.println();
        }
    }

}
