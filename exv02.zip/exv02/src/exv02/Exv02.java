package exv02;
import java.util.Scanner;

public class Exv02 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n = 10, achou = 0;
        double v[] = new double[n];

        System.out.println("digite " + n + " numeros");

        for (int i = 0; i < n; i++) {
            System.out.print("numero " + (i + 1) + ": ");
            v[i] = teclado.nextDouble();
        }

        System.out.println();

        for (int i = 0; i < n; i++) {
            if (v[i] > 50) {
                achou = 1;
                System.out.println(v[i]);
            }
        }

        if (achou == 0) {
            System.out.println("nao teve numero maior que 50");
        }
    }
}