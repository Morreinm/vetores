package exv01;

import java.util.Scanner;

public class Exv01 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = 10;
        double v[] = new double[n];

        System.out.println("digite " + n + " numeros");

        for (int i = 0; i < n; i++) {
            System.out.print("numero " + (i + 1) + ": ");
            v[i] = sc.nextDouble();
        }

        System.out.println();

        for (int i = 0; i < n; i++) {
            if (v[i] % 2 == 0) {
                System.out.println(v[i]);
            }

        }

    }
}
