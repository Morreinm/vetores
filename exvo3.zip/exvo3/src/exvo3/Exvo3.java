package exvo3;
import java.util.Scanner;

public class Exvo3 {

    public static void main(String[] args) {
    Scanner teclado = new Scanner(System.in);
        int v[] = new int[9], d, j, qtd = 0;

        System.out.println("digite 9 numeros");

        for (int i = 0; i < 9; i++) {
            System.out.print("num" + (i + 1) + ": ");
            v[i] = teclado.nextInt();
        }

        System.out.println();
        System.out.println("os numeros primos sao:");

        for (int i = 0; i < 9; i++) {
            d = 0;
            j = 1;

            while (j <= v[i]) {
                if (v[i] % j == 0) {
                    d++;
                }
                j++;
            }

            if (d <= 2) {
                System.out.println(v[i]);
                qtd++;
            }
        }

        if (qtd == 0) {
            System.out.println("nao ha numeros primos");
        }
    }
    
}
