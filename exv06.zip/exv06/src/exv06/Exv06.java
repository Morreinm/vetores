package exv06;

import java.util.Scanner;

public class Exv06 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        int n = 2;
        String c[] = new String[n];
        double v[] = new double[n];
        double p, maior = 0, menor = 1000;
        String mais = "", menos = "";

        System.out.println("digite o preco do combustivel");
        p = teclado.nextDouble();

        System.out.println("digite os dados dos carros");

        for (int i = 0; i < n; i++) {
            teclado.nextLine();

            System.out.print("nome: ");
            c[i] = teclado.nextLine();

            System.out.print("consumo em km/l: ");
            v[i] = teclado.nextDouble();
        }

        for (int i = 0; i < n; i++) {
            if (v[i] > maior) {
                maior = v[i];
                mais = c[i];
            }

            if (v[i] < menor) {
                menor = v[i];
                menos = c[i];
            }
        }

        System.out.println("carro mais economico:" + mais);
        System.out.println("carro menos economico:" + menos);

        System.out.println("custo da viagem d 780 km");

        for (int i = 0; i < n; i++) {
            System.out.println(c[i] + ": " + (780 / v[i] * p) + " reais");
        }
    }

}
